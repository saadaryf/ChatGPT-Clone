import React from 'react'
import '../css/ChatBox.css'


const ChatBox = () => {
  return (
    <div className='chat-box'>
      
    </div>
  )
}

export default ChatBox
